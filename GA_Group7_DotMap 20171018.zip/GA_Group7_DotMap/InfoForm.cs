﻿using System.Windows.Forms;

namespace GA_Group7_DotMap
{
    public partial class InfoForm : Form
    {
        public InfoForm()
        {
            InitializeComponent();
            MaximumSize = Size;
            MinimumSize = Size;
            ControlBox = false;
        }

        public void UpdateMessage(string message)
        {
            lb_info.Text = message;
        }
    }
}
